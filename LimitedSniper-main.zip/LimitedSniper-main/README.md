# LimitedSniper
It is a Limited item sniper it catches items that are at a 50% discount or higher and either auto buys for you, or you can manualy do it
